import java.util.Scanner;

public class AccountCreation {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.print("Enter username (must contain an underscore and be no more than 5 characters long): ");
        String username = scanner.nextLine();
        
        if (login.checkUserName(username)) {
            System.out.println("Username successfully captured.");
        } else {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return; 
        }

        System.out.print("Enter password (must be at least 8 characters long, contain a capital letter, a number, and a special character): ");
        String password = scanner.nextLine();

        if (login.checkPasswordComplexity(password)) {
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return; 
        }

        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        String registrationStatus = login.registerUser(username, password, firstName, lastName);
        System.out.println(registrationStatus);

        System.out.println("\n--- Login ---");
        System.out.print("Enter username: ");
        String usernameInput = scanner.nextLine();
        System.out.print("Enter password: ");
        String passwordInput = scanner.nextLine();

        if (login.loginUser(usernameInput, passwordInput)) {
            System.out.println(login.returnLoginStatus());
        } else {
            System.out.println("Username or password incorrect, please try again.");
        }
    }
}

class Login {
    private String storedUsername;
    private String storedPassword;
    private String firstName;
    private String lastName;

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 && 
               password.chars().anyMatch(Character::isUpperCase) && 
               password.chars().anyMatch(Character::isDigit) && 
               password.chars().anyMatch(ch -> "!@#$%^&*()_+[]{}|;':\",.<>?/`~".indexOf(ch) >= 0);
    }

    public String registerUser(String username, String password, String firstName, String lastName) {
        this.storedUsername = username;
        this.storedPassword = password;
        this.firstName = firstName;
        this.lastName = lastName;
        return "Account created for: " + firstName + " " + lastName;
    }

    public boolean loginUser(String username, String password) {
        return username.equals(storedUsername) && password.equals(storedPassword);
    }

    public String returnLoginStatus() {
        return "Welcome " + firstName + ", " + lastName + "! It is great to see you again.";
    }
}
